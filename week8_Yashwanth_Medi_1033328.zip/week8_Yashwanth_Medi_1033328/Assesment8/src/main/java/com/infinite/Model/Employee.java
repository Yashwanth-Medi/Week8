package com.infinite.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")//Table name
public class Employee {

	@Id
	@Column(name = "empid")
	public int empid;

	@Column(name = "First_Name")
	public String FirstName;

	@Column(name = "Last_name")
	public String LastName;

	@Column(name = "Department")
	public String Department;
	//setters and getters
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}
//Constructor
	public Employee() {
		// TODO Auto-generated constructor stub
	}

}
