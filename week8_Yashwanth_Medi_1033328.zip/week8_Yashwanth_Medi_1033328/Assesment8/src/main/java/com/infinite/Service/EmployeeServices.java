package com.infinite.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.Model.Employee;
import com.infinite.Repositary.EmployeeRespo;

@Service
public class EmployeeServices {
	
	@Autowired
	EmployeeRespo employeeR;
	public Employee createEmployee(Employee employee) {
		return employeeR.save(employee);
	}
 
	// READ
	public List<Employee> getEmployees() {
		return employeeR.findAll();
	}
	public void deleteEmployee(Employee Id){
		employeeR.delete(Id);
	}

	
 
}
