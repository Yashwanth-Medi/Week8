package com.infinite.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.Model.Employee;
import com.infinite.Service.EmployeeServices;

@RestController
@RequestMapping("/api")
public class MyController {

	@Autowired
	EmployeeServices EmployeeService;

	// Save the data of employee
	@RequestMapping(value = "/employees", method = RequestMethod.POST)
	public Employee createEmployee(@RequestBody Employee emp) {
		System.out.println("creation of table employee.");
		return EmployeeService.createEmployee(emp);
	}

	// Dispaly the data
	@RequestMapping(value = "/reademployees", method = RequestMethod.GET)
	public List<Employee> readEmployees() {
		System.out.println("Reading of table employee");
		return EmployeeService.getEmployees();
	}

}
