package com.infinite.Repositary;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infinite.Model.Employee;

@Repository
public interface EmployeeRespo extends JpaRepository<Employee, Long> {




	
}
